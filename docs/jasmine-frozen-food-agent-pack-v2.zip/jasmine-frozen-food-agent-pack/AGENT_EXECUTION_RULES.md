# AI Agent Execution Rules

## Misi
Ubah codebase Raf Store menjadi Jasmine Frozen Food dengan desain locked di `reference/homepage-locked.png`, sambil mempertahankan fitur transaksi existing dan memperluas backend agar storefront sepenuhnya data-driven.

## Aturan keras
- Audit file existing sebelum mengubahnya. Jangan menebak struktur.
- Jangan menghapus fitur cart, checkout, auth, order tracking, stock, atau admin existing.
- Hindari rewrite massal satu langkah. Kerjakan fase dan task secara berurutan.
- Jangan menambah library UI besar tanpa kebutuhan nyata. Gunakan Tailwind dan `lucide-react` existing.
- Server Component sebagai default; gunakan Client Component hanya untuk interaksi.
- Semua operasi mutasi harus memiliki validasi server-side dan otorisasi admin bila perlu.
- Harga disimpan sebagai integer rupiah.
- Stok tidak boleh negatif.
- Jangan hard-code data bisnis yang seharusnya dapat dikelola admin.
- Jangan membaca atau menulis `.env` ke dokumentasi/log.
- Setiap perubahan schema wajib disertai migration dan seed update.

## Workflow setiap task
1. Baca task dan file terkait.
2. Catat risiko regresi.
3. Implementasi paling kecil yang lengkap.
4. Jalankan typecheck/lint/build atau test yang relevan.
5. Perbaiki error sebelum pindah task.
6. Laporkan file berubah, keputusan, dan hasil verifikasi.

## Checkpoint wajib
Berhenti dan minta verifikasi manusia setelah:
- Fase 1: foundation + design system.
- Fase 2: homepage desktop/mobile selesai dengan mock/seed data.
- Fase 4: migration schema dan admin CMS selesai.
- Fase 6: checkout dan order regression test selesai.

## File yang kemungkinan besar terdampak
- `app/page.tsx`, `app/globals.css`, `app/layout.tsx`
- `components/catalog-section.tsx`, `catalog-search.tsx`, `cart-button.tsx`, `product-detail.tsx`
- komponen baru di `components/storefront/*`
- `db/schema.ts`, migrations, `scripts/seed.mjs`
- service/repository di `lib/*`
- route handlers di `app/api/*`
- admin pages/components.
