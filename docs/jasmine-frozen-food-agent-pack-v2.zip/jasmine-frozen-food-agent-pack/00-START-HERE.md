# Jasmine Frozen Food — AI Agent Execution Pack

## Tujuan
Dokumen ini adalah sumber kebenaran untuk merevamp repository `rafiulm/raf-store` menjadi **Jasmine Frozen Food**, berdasarkan desain homepage merah-krem yang sudah dikunci pada `reference/homepage-locked.png`.

## Baseline repository
- Next.js 16 + React 19 + TypeScript
- Tailwind CSS 4
- Drizzle ORM
- SQLite (`better-sqlite3`)
- Storefront, cart persisten, checkout transfer manual, akun pelanggan, pelacakan pesanan, admin produk/order/stok.

## Keputusan arsitektur
1. **Tidak rewrite dari nol.** Pertahankan Next.js full-stack dan pola App Router.
2. Revamp dilakukan vertikal: UI storefront → model data → API/service → admin CMS → migrasi data → pengujian.
3. SQLite tetap didukung untuk local development. Untuk production, siapkan adapter PostgreSQL sebagai target deployment tanpa memblokir fase UI.
4. Semua konten homepage harus dikelola dari admin atau seed, bukan hard-coded permanen.
5. Desain locked adalah acuan visual, tetapi implementasi wajib responsif, accessible, dan data-driven.

## Urutan membaca untuk AI agent
1. `AGENT_EXECUTION_RULES.md`
2. `PRD.md`
3. `ARCHITECTURE.md`
4. `DESIGN_SYSTEM.md`
5. `FRONTEND_SPEC.md`
6. `BACKEND_SPEC.md`
7. `DATABASE_SCHEMA.md`
8. `API_CONTRACT.md`
9. `MIGRATION_PLAN.md`
10. `IMPLEMENTATION_ORDER.md`
11. `TASK_BREAKDOWN.md`
12. `ACCEPTANCE_TESTS.md`

## Definition of Done global
- Branding Raf Store hilang dari customer-facing UI.
- Homepage sesuai reference pada desktop dan tetap usable pada mobile.
- Product, category, promo, banner, testimonial, trust badge, cooking guide, marketplace, dan site settings berasal dari database.
- Admin dapat mengelola konten utama tanpa edit source code.
- Existing cart, checkout, account, order, stock, dan payment proof tetap berfungsi.
- `npm run lint` dan `npm run build` lulus.
- Migration dan seed dapat dijalankan pada database kosong.
